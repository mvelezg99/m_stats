***

To use and explore the library, you can install it with PyPi.
```
$ pip install m_stats
```
And then import it into your files.
```python
import m_stats as ms
```
And to use its functionalities, you should access to them in this way:
```python
ms.linregr.regression(x, y)
```
***